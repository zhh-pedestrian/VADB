package com.example.entity;

import javax.persistence.*;

@Table(name = "rna")
public class Rna {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)   /*主键id且自增*/
    private Integer id;
    @Column(name = "VADB_ID")
    private String vadb_id;
    @Column(name = "Gene_ID")
    private String gene_id;
    @Column(name = "Gene_Symbol")
    private String gene_symbol;
    @Column(name = "lo2FoldChange")
    private String lo2foldchange;
    @Column(name = "P_Value")
    private String p_value;
    @Column(name = "P_Adjust")
    private String p_adjust;
    @Column(name = "treatment")
    private String treatment;
    @Column(name = "Tissue")
    private String tissue;
    @Column(name = "DOI")
    private String doi;
    @Column(name = "addtime")
    private String addtime;

    public Rna(Integer id, String vadb_id, String gene_id, String gene_symbol, String lo2foldchange, String p_value, String p_adjust, String treatment, String tissue, String doi, String addtime) {
        this.id = id;
        this.vadb_id = vadb_id;
        this.gene_id = gene_id;
        this.gene_symbol = gene_symbol;
        this.lo2foldchange = lo2foldchange;
        this.p_value = p_value;
        this.p_adjust = p_adjust;
        this.treatment = treatment;
        this.tissue = tissue;
        this.doi = doi;
        this.addtime = addtime;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getVadb_id() {
        return vadb_id;
    }

    public void setVadb_id(String vadb_id) {
        this.vadb_id = vadb_id;
    }

    public String getGene_id() {
        return gene_id;
    }

    public void setGene_id(String gene_id) {
        this.gene_id = gene_id;
    }

    public String getGene_symbol() {
        return gene_symbol;
    }

    public void setGene_symbol(String gene_symbol) {
        this.gene_symbol = gene_symbol;
    }

    public String getLo2foldchange() {
        return lo2foldchange;
    }

    public void setLo2foldchange(String lo2foldchange) {
        this.lo2foldchange = lo2foldchange;
    }

    public String getP_value() {
        return p_value;
    }

    public void setP_value(String p_value) {
        this.p_value = p_value;
    }

    public String getP_adjust() {
        return p_adjust;
    }

    public void setP_adjust(String p_adjust) {
        this.p_adjust = p_adjust;
    }

    public String getTreatment() {
        return treatment;
    }

    public void setTreatment(String treatment) {
        this.treatment = treatment;
    }

    public String getTissue() {
        return tissue;
    }

    public void setTissue(String tissue) {
        this.tissue = tissue;
    }

    public String getDoi() {
        return doi;
    }

    public void setDoi(String doi) {
        this.doi = doi;
    }

    public String getAddtime() {
        return addtime;
    }

    public void setAddtime(String addtime) {
        this.addtime = addtime;
    }
}
