package com.example.entity;

import javax.persistence.*;

@Table(name = "journal")
public class Journal {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)   /*主键id且自增*/
    private Integer id;
    @Column(name = "Title")
    private String title;
    @Column(name = "Author")
    private String author;
    @Column(name = "Journal")
    private String journal;
    @Column(name = "Abstract")
    private String abstract1;
    @Column(name = "Data")
    private String data;
    @Column(name = "DOI")
    private String doi;
    @Column(name = "PMID")
    private String pmid;
    @Column(name = "...8")
    private String f8;
    @Column(name = "...9")
    private String f9;
    @Column(name = "...10")
    private String f10;
    @Column(name = "...11")
    private String f11;
    @Column(name = "addtime")
    private String addtime;

    public Journal(Integer id, String title, String author, String journal, String abstract1, String data, String doi, String pmid, String f8, String f9, String f10, String f11, String addtime) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.journal = journal;
        this.abstract1 = abstract1;
        this.data = data;
        this.doi = doi;
        this.pmid = pmid;
        this.f8 = f8;
        this.f9 = f9;
        this.f10 = f10;
        this.f11 = f11;
        this.addtime = addtime;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getJournal() {
        return journal;
    }

    public void setJournal(String journal) {
        this.journal = journal;
    }

    public String getAbstract1() {
        return abstract1;
    }

    public void setAbstract1(String abstract1) {
        this.abstract1 = abstract1;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getDoi() {
        return doi;
    }

    public void setDoi(String doi) {
        this.doi = doi;
    }

    public String getPmid() {
        return pmid;
    }

    public void setPmid(String pmid) {
        this.pmid = pmid;
    }

    public String getF8() {
        return f8;
    }

    public void setF8(String f8) {
        this.f8 = f8;
    }

    public String getF9() {
        return f9;
    }

    public void setF9(String f9) {
        this.f9 = f9;
    }

    public String getF10() {
        return f10;
    }

    public void setF10(String f10) {
        this.f10 = f10;
    }

    public String getF11() {
        return f11;
    }

    public void setF11(String f11) {
        this.f11 = f11;
    }

    public String getAddtime() {
        return addtime;
    }

    public void setAddtime(String addtime) {
        this.addtime = addtime;
    }
}
