package com.example.entity;

import javax.persistence.*;

@Table(name = "protein")
public class Protein {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)   /*主键id且自增*/
    private Integer id;
    @Column(name = "VADB_ID")
    private String vadb_id;
    @Column(name = "Uniprot_ID")
    private String uniprot_id;
    @Column(name = "Gene_Symbol")
    private String gene_symbol;
    @Column(name = "logFC")
    private String logfc;
    @Column(name = "P.Value")
    private String p_value;
    @Column(name = "adj.P.Val")
    private String adj_p_val;
    @Column(name = "Tissue")
    private String tissue;
    @Column(name = "DOI")
    private String doi;
    @Column(name = "addtime")
    private String addtime;

    public Protein(Integer id, String vadb_id, String uniprot_id, String gene_symbol, String logfc, String p_value, String adj_p_val, String tissue, String doi, String addtime) {
        this.id = id;
        this.vadb_id = vadb_id;
        this.uniprot_id = uniprot_id;
        this.gene_symbol = gene_symbol;
        this.logfc = logfc;
        this.p_value = p_value;
        this.adj_p_val = adj_p_val;
        this.tissue = tissue;
        this.doi = doi;
        this.addtime = addtime;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getVadb_id() {
        return vadb_id;
    }

    public void setVadb_id(String vadb_id) {
        this.vadb_id = vadb_id;
    }

    public String getUniprot_id() {
        return uniprot_id;
    }

    public void setUniprot_id(String uniprot_id) {
        this.uniprot_id = uniprot_id;
    }

    public String getGene_symbol() {
        return gene_symbol;
    }

    public void setGene_symbol(String gene_symbol) {
        this.gene_symbol = gene_symbol;
    }

    public String getLogfc() {
        return logfc;
    }

    public void setLogfc(String logfc) {
        this.logfc = logfc;
    }

    public String getP_value() {
        return p_value;
    }

    public void setP_value(String p_value) {
        this.p_value = p_value;
    }

    public String getAdj_p_val() {
        return adj_p_val;
    }

    public void setAdj_p_val(String adj_p_val) {
        this.adj_p_val = adj_p_val;
    }

    public String getTissue() {
        return tissue;
    }

    public void setTissue(String tissue) {
        this.tissue = tissue;
    }

    public String getDoi() {
        return doi;
    }

    public void setDoi(String doi) {
        this.doi = doi;
    }

    public String getAddtime() {
        return addtime;
    }

    public void setAddtime(String addtime) {
        this.addtime = addtime;
    }
}
