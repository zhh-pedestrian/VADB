package com.example.entity;

import javax.persistence.*;

@Table(name = "metabolomics")
public class Metabolite {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)   /*主键id且自增*/
    private Integer id;
    @Column(name = "VADB_ID")
    private String vadb_id;
    @Column(name = "Metabolite_ID")
    private String metabolite_id;
    @Column(name = "Compound Name")
    private String compound_name;
    @Column(name = "Super Pathway")
    private String super_pathway;
    @Column(name = "Sub Pathway")
    private String sub_pathway;
    @Column(name = "Lipid Category")
    private String lipid_category;
    @Column(name = "Lipid Class")
    private String lipid_class;
    @Column(name = "Lipid Subclass")
    private String lipid_subclass;
    @Column(name = "Coefficient")
    private String coefficient;
    @Column(name = "P_Value")
    private String p_value;
    @Column(name = "P_Adjust")
    private String p_adjust;
    @Column(name = "Platform")
    private String platform;
    @Column(name = "DOI")
    private String doi;
    @Column(name = "addtime")
    private String addtime;

    public Metabolite(Integer id, String vadb_id, String metabolite_id, String compound_name, String super_pathway, String sub_pathway, String lipid_category, String lipid_class, String lipid_subclass, String coefficient, String p_value, String p_adjust, String platform, String doi, String addtime) {
        this.id = id;
        this.vadb_id = vadb_id;
        this.metabolite_id = metabolite_id;
        this.compound_name = compound_name;
        this.super_pathway = super_pathway;
        this.sub_pathway = sub_pathway;
        this.lipid_category = lipid_category;
        this.lipid_class = lipid_class;
        this.lipid_subclass = lipid_subclass;
        this.coefficient = coefficient;
        this.p_value = p_value;
        this.p_adjust = p_adjust;
        this.platform = platform;
        this.doi = doi;
        this.addtime = addtime;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getVadb_id() {
        return vadb_id;
    }

    public void setVadb_id(String vadb_id) {
        this.vadb_id = vadb_id;
    }

    public String getMetabolite_id() {
        return metabolite_id;
    }

    public void setMetabolite_id(String metabolite_id) {
        this.metabolite_id = metabolite_id;
    }

    public String getCompound_name() {
        return compound_name;
    }

    public void setCompound_name(String compound_name) {
        this.compound_name = compound_name;
    }

    public String getSuper_pathway() {
        return super_pathway;
    }

    public void setSuper_pathway(String super_pathway) {
        this.super_pathway = super_pathway;
    }

    public String getSub_pathway() {
        return sub_pathway;
    }

    public void setSub_pathway(String sub_pathway) {
        this.sub_pathway = sub_pathway;
    }

    public String getLipid_category() {
        return lipid_category;
    }

    public void setLipid_category(String lipid_category) {
        this.lipid_category = lipid_category;
    }

    public String getLipid_class() {
        return lipid_class;
    }

    public void setLipid_class(String lipid_class) {
        this.lipid_class = lipid_class;
    }

    public String getLipid_subclass() {
        return lipid_subclass;
    }

    public void setLipid_subclass(String lipid_subclass) {
        this.lipid_subclass = lipid_subclass;
    }

    public String getCoefficient() {
        return coefficient;
    }

    public void setCoefficient(String coefficient) {
        this.coefficient = coefficient;
    }

    public String getP_value() {
        return p_value;
    }

    public void setP_value(String p_value) {
        this.p_value = p_value;
    }

    public String getP_adjust() {
        return p_adjust;
    }

    public void setP_adjust(String p_adjust) {
        this.p_adjust = p_adjust;
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public String getDoi() {
        return doi;
    }

    public void setDoi(String doi) {
        this.doi = doi;
    }

    public String getAddtime() {
        return addtime;
    }

    public void setAddtime(String addtime) {
        this.addtime = addtime;
    }
}
