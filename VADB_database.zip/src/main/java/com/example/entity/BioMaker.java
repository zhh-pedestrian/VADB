package com.example.entity;

import javax.persistence.*;

@Table(name = "biomaker")
public class BioMaker {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)   /*主键id且自增*/
    private Integer id;
    @Column(name = "VADB_ID")
    private String vadb_id;
    @Column(name = "Gene_Symbol")
    private String gene_symbol;
    @Column(name = "Alis")
    private String alis;
    @Column(name = "Gene_Name")
    private String gene_name;
    @Column(name = "Function")
    private String function;
    @Column(name = "GeneSet")
    private String geneset;
    @Column(name = "Species")
    private String species;
    @Column(name = "KEGG_ID")
    private String kegg_id;
    @Column(name = "KEGG_Name")
    private String kegg_name;
    @Column(name = "ENTREZ_ID")
    private String entrez_id;
    @Column(name = "Year")
    private String year;
    @Column(name = "Title")
    private String title;
    @Column(name = "DOI")
    private String doi;
    @Column(name = "addtime")
    private String addtime;

    public BioMaker(Integer id, String vadb_id, String gene_symbol, String alis, String gene_name, String function, String geneset, String species, String kegg_id, String kegg_name, String entrez_id, String year, String title, String doi, String addtime) {
        this.id = id;
        this.vadb_id = vadb_id;
        this.gene_symbol = gene_symbol;
        this.alis = alis;
        this.gene_name = gene_name;
        this.function = function;
        this.geneset = geneset;
        this.species = species;
        this.kegg_id = kegg_id;
        this.kegg_name = kegg_name;
        this.entrez_id = entrez_id;
        this.year = year;
        this.title = title;
        this.doi = doi;
        this.addtime = addtime;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getVadb_id() {
        return vadb_id;
    }

    public void setVadb_id(String vadb_id) {
        this.vadb_id = vadb_id;
    }

    public String getGene_symbol() {
        return gene_symbol;
    }

    public void setGene_symbol(String gene_symbol) {
        this.gene_symbol = gene_symbol;
    }

    public String getAlis() {
        return alis;
    }

    public void setAlis(String alis) {
        this.alis = alis;
    }

    public String getGene_name() {
        return gene_name;
    }

    public void setGene_name(String gene_name) {
        this.gene_name = gene_name;
    }

    public String getFunction() {
        return function;
    }

    public void setFunction(String function) {
        this.function = function;
    }

    public String getGeneset() {
        return geneset;
    }

    public void setGeneset(String geneset) {
        this.geneset = geneset;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public String getKegg_id() {
        return kegg_id;
    }

    public void setKegg_id(String kegg_id) {
        this.kegg_id = kegg_id;
    }

    public String getKegg_name() {
        return kegg_name;
    }

    public void setKegg_name(String kegg_name) {
        this.kegg_name = kegg_name;
    }

    public String getEntrez_id() {
        return entrez_id;
    }

    public void setEntrez_id(String entrez_id) {
        this.entrez_id = entrez_id;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDoi() {
        return doi;
    }

    public void setDoi(String doi) {
        this.doi = doi;
    }

    public String getAddtime() {
        return addtime;
    }

    public void setAddtime(String addtime) {
        this.addtime = addtime;
    }
}
