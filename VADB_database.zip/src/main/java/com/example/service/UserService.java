package com.example.service;

import com.example.dao.UserDao;
import com.example.entity.Params;
import com.example.entity.User;
import com.example.exception.CustomException;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class UserService {
    @Resource
    private UserDao userDao;
    public List<User> getAllUser(){
        return userDao.getAllUser();
    }

    public PageInfo<User> findBySearch(Params params){
        /*分页功能*/
        PageHelper.startPage(params.getPageNum(),params.getPageSize());
        List<User> list = userDao.findBySearch(params);
        return PageInfo.of(list);
    }

    public void add(User user){
        //非空判断
        if(user.getName() == null || "".equals(user.getName())){
            throw new CustomException("用户名不能为空");
        }
        if(user.getPassword() == null || "".equals(user.getPassword())){
            throw new CustomException("密码不能为空");
        }
        if(user.getPhone() == null || "".equals(user.getPhone())){
            throw new CustomException("手机号不能为空");
        }
        if(user.getEmail() == null || "".equals(user.getEmail())){
            throw new CustomException("邮箱不能为空");
        }
        //重复性判断
        User user1 = userDao.findByName(user.getName());
        if(user1 != null){
            throw new CustomException(("该用户名已存在"));
        }
        userDao.insertSelective(user); //插入该对象
    }
    public User login(User user){
        //非空判断
        if(user.getName() == null || "".equals(user.getName())){
            throw new CustomException("用户名不能为空");
        }
        if(user.getPassword() == null || "".equals(user.getPassword())){
            throw new CustomException("密码不能为空");
        }
        //根据用户名和密码查询数据库信息
        User user1 = userDao.findByNameAndPassword(user.getName(),user.getPassword());
        if(user1 == null){
            //没有查到
            throw new CustomException(("用户名或密码输入错误"));
        }
        return user1; //返回查到的信息
    }
}
