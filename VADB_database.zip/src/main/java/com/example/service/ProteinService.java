package com.example.service;

import com.example.dao.ProteinDao;
import com.example.dao.UserDao;
import com.example.entity.Params;
import com.example.entity.Protein;
import com.example.entity.User;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
@Service
public class ProteinService {
    @Resource
    private ProteinDao proteinDao;
    public PageInfo<Protein> findBySearch(Params params){
        /*分页功能*/
        PageHelper.startPage(params.getPageNum(),params.getPageSize());
        List<Protein> list = proteinDao.findBySearch(params);
        return PageInfo.of(list);
    }
}
