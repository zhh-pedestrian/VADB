package com.example.service;

import com.example.dao.RnaDao;
import com.example.entity.Params;
import com.example.entity.Rna;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class RnaService {
    @Resource
    private RnaDao rnaDao;
    public PageInfo<Rna> findBySearch(Params params){
        /*分页功能*/
        PageHelper.startPage(params.getPageNum(),params.getPageSize());
        List<Rna> list = rnaDao.findBySearch(params);
        return PageInfo.of(list);
    }
}
