package com.example.service;

import com.example.dao.JournalDao;
import com.example.entity.Journal;
import com.example.entity.Params;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class JournalService {
    @Resource
    private JournalDao journalDao;
    public PageInfo<Journal> findBySearch(Params params){
        /*分页功能*/
        PageHelper.startPage(params.getPageNum(),params.getPageSize());
        List<Journal> list = journalDao.findBySearch(params);
        return PageInfo.of(list);
    }
}
