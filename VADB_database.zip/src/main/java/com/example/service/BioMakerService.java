package com.example.service;

import com.example.dao.BioMakerDao;
import com.example.dao.ProteinDao;
import com.example.entity.BioMaker;
import com.example.entity.Params;
import com.example.entity.Protein;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class BioMakerService {
    @Resource
    private BioMakerDao biomakerDao;
    public PageInfo<BioMaker> findBySearch(Params params){
        /*分页功能*/
//        System.out.println("Params: " + params);
        PageHelper.startPage(params.getPageNum(),params.getPageSize());
        List<BioMaker> list = biomakerDao.findBySearch(params);
        return PageInfo.of(list);
    }
}
