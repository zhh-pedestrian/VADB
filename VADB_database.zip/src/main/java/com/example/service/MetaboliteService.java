package com.example.service;

import com.example.dao.MetaboliteDao;
import com.example.entity.Metabolite;
import com.example.entity.Params;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class MetaboliteService {
    @Resource
    private MetaboliteDao metaboliteDao;
    public PageInfo<Metabolite> findBySearch(Params params){
        /*分页功能*/
        PageHelper.startPage(params.getPageNum(),params.getPageSize());
        List<Metabolite> list = metaboliteDao.findBySearch(params);
        return PageInfo.of(list);
    }
}
