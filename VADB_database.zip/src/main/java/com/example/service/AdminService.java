package com.example.service;

import com.example.dao.AdminDao;
import com.example.entity.Admin;
import com.example.exception.CustomException;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class AdminService {
    @Resource
    private AdminDao adminDao;
    public Admin login(Admin admin){
        //非空判断
        if(admin.getName() == null || "".equals(admin.getName())){
            throw new CustomException("用户名不能为空");
        }
        if(admin.getPassword() == null || "".equals(admin.getPassword())){
            throw new CustomException("密码不能为空");
        }
        //根据用户名和密码查询数据库信息
        Admin admin1 = adminDao.findByNameAndPassword(admin.getName(),admin.getPassword());
        if(admin1 == null){
            //没有查到
            throw new CustomException(("用户名或密码输入错误"));
        }
        return admin1; //返回查到的信息
    }
}
