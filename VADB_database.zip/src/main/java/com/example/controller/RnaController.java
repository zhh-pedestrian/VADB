package com.example.controller;

import com.example.common.Result;
import com.example.entity.Params;
import com.example.entity.Rna;
import com.example.service.RnaService;
import com.github.pagehelper.PageInfo;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@CrossOrigin
@RestController
@RequestMapping("/rna")
public class RnaController {
    @Resource
    private RnaService rnaService;


    @GetMapping("/search")
    public Result findBysearch(Params params) {
        PageInfo<Rna> info = rnaService.findBySearch(params);
        return Result.success(info);
    }
}
