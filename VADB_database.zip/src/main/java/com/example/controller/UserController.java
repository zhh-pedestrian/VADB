package com.example.controller;

import com.example.common.Result;
import com.example.entity.Params;
import com.example.entity.User;
import com.example.service.UserService;
import com.github.pagehelper.PageInfo;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
@CrossOrigin
@RestController
@RequestMapping("/user")
public class UserController {
    @Resource
    private UserService userService;

    @PostMapping("/login")
    public Result login(@RequestBody User user){
        User loginuser = userService.login(user);
        return Result.success(loginuser);
    }

    @PostMapping("/register")
    public Result register(@RequestBody User user){
        userService.add(user);
        return Result.success();
    }

    @GetMapping
    public Result getAllUser(){
        List<User> list = userService.getAllUser();
        return Result.success(list);
    }

    @GetMapping("/search")
    public Result findBysearch(Params params){
        PageInfo<User> info = userService.findBySearch(params);
        return Result.success(info);
    }
}
