package com.example.controller;

import com.example.common.Result;
import com.example.entity.Metabolite;
import com.example.entity.Params;
import com.example.service.MetaboliteService;
import com.github.pagehelper.PageInfo;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@CrossOrigin
@RestController
@RequestMapping("/metabolite")
public class MetaboliteController {
    @Resource
    private MetaboliteService metaboliteService;


    @GetMapping("/search")
    public Result findBysearch(Params params) {
        PageInfo<Metabolite> info = metaboliteService.findBySearch(params);
        return Result.success(info);
    }
}
