package com.example.controller;

import com.example.common.Result;
import com.example.entity.Admin;
import com.example.entity.User;
import com.example.service.AdminService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@CrossOrigin
@RestController
@RequestMapping("/admin")
public class AdminController {
    @Resource
    private AdminService adminService;
    @PostMapping("/login")
    public Result login(@RequestBody Admin admin){
        Admin loginadmin = adminService.login(admin);
        return Result.success(loginadmin);
    }
}
