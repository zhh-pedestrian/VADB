package com.example.controller;

import com.example.common.Result;
import com.example.entity.BioMaker;
import com.example.entity.Params;
import com.example.entity.Protein;
import com.example.service.BioMakerService;
import com.example.service.ProteinService;
import com.github.pagehelper.PageInfo;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@CrossOrigin
@RestController
@RequestMapping("/biomaker")
public class BioMakerController {
    @Resource
    private BioMakerService biomakerService;


    @GetMapping("/search")
    public Result findBysearch(Params params) {
        PageInfo<BioMaker> info = biomakerService.findBySearch(params);
        return Result.success(info);
    }
}
