package com.example.dao;

import com.example.entity.BioMaker;
import com.example.entity.Params;
import com.example.entity.Protein;
import org.apache.ibatis.annotations.Param;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

public interface BioMakerDao extends Mapper<BioMaker> {
    List<BioMaker> findBySearch(@Param("params") Params params);
}
