package com.example.dao;

import com.example.entity.Metabolite;
import com.example.entity.Params;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

@Repository
public interface MetaboliteDao extends Mapper<Metabolite> {
    List<Metabolite> findBySearch(@Param("params") Params params);
}
