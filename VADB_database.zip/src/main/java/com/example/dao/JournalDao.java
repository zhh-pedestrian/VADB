package com.example.dao;

import com.example.entity.Journal;
import com.example.entity.Params;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface JournalDao {
    List<Journal> findBySearch(@Param("params") Params params);
}
